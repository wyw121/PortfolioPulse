#!/bin/bash
echo "🔄 重启 PortfolioPulse 前端..."
pm2 restart portfoliopulse-frontend
echo "✅ 重启完成"
