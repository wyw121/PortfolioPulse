#!/bin/bash
echo "🛑 停止 PortfolioPulse 前端..."
pm2 stop portfoliopulse-frontend
echo "✅ 已停止"
